import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-icons',
  templateUrl: './icons.component.html'
})
export class AppIconsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
